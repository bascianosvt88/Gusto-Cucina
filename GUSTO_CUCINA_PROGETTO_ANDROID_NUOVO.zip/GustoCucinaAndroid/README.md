# Gusto Cucina Android

Nuovo progetto Android WebView per l'app Cucina Gusto.

- Nome app: Gusto Cucina
- Application ID: `it.gusto.cucina`
- HTML: `app/src/main/assets/index.html`
- Icona: risorse `mipmap-*`
- Build GitHub Actions: `.github/workflows/android.yml`

## Creazione APK
Caricare il contenuto di questa cartella in un nuovo repository GitHub (branch `main`), quindi aprire Actions e avviare **Build Gusto Cucina APK**. L'APK debug sarà disponibile tra gli Artifact della workflow.
